USE judo;

UPDATE judoka set id_ceinture = id_ceinture + 1 -- On incrémente le niveau de ceinture de 1
WHERE id_judoka < 6; -- Pour toutes les entrées dont l'ID est strictement inférieure à 6. [WHERE id_judoka <= 5;] fonctionne aussi