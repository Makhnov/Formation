-- On crée deux nouveaux judokas
INSERT into judoka(nom_judoka, prenom_judoka, age_judoka, id_sexe, id_ceinture)
VALUES
	('Rinner', 'Teddy', 33, 1, 7),
    ('Agbégnénou', 'Clarisse', 30, 2, 7);

-- On enlève les deux entrées précédemment crées de la base de données    
DELETE from judoka 
WHERE id_judoka in (11, 12);