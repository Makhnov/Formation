USE judo;

-- Ajout des différents types de ceinture (dans l'ordre de force, de 1 à 7)
INSERT into ceinture(couleur_ceinture) 
VALUES
	('blanche'),
    ('jaune'),
    ('orange'),
    ('verte'),
	('bleue'),
    ('marron'),
	('noire');

-- Ajout des différents sexe possibles : H = Homme id 1, F = Femme id 2
-- Comme on est woke et qu'on ne veut pas d'ennuis dans le digital on rajoute une option : A = Autre id 3
INSERT into sexe(type_sexe)
VALUES
	('H'),
    ('F'),
    ('A');
    
-- On rajoute dix judokas dans notre base de données
INSERT into judoka(nom_judoka, prenom_judoka, age_judoka, id_sexe, id_ceinture)
VALUES
	('Lachance', 'Dominique', 16, 2, 2),
    ('Porter', 'Gilbert', 18, 1, 3),
    ('Lemaître', 'Anne', 15, 2, 4),
    ('Robert', 'Juliette', 12, 2, 1),
	('Montminy', 'Pierre', 17, 1, 5),
    ('Charette', 'Pascal', 21, 1, 6),
    ('Guay', 'Émilie', 19, 2, 6),
	('Maheu', 'Louise', 14, 2, 4),
    ('Poulin', 'Raymond', 26, 1, 7),
    ('Dupret', 'Alain', 20, 1, 6);
    
-- On rajoute quatre compétitions régionales dans notre base de données
INSERT into competition(nom_competition, debut_competition, fin_competition)
VALUES
	('judo31', '2021-02-06', '2021-02-07'),
    ('judo11', '2021-02-27', '2021-02-28'),
    ('judo81', '2021-03-20', '2021-03-21'),
    ('judo82', '2021-04-17', '2021-04-18');

-- On associe les judokas aux compétitions auxquelles ils ont participé
-- Exemple, ligne 7 : (2, 9) signifie que Raymond POULIN (id9) a participté à la compétion dans l'aude les 27 et 28 février (id2)
INSERT into participer(id_competition, id_judoka)
VALUES
	(1, 1),
    (1, 3),
    (1, 4),
	(2, 2),
    (2, 5),
    (2, 6),
    (2, 9),
    (3, 10),
    (3, 9),
    (4, 1),
    (4, 3),
    (4, 8),
    (4, 4);