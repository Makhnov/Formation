-- Création de la base de donnée
CREATE DATABASE judo;
USE judo;

-- Création des (4) tables initiales : judokas, sexe, ceinture et compétition =>
CREATE TABLE judoka(
id_judoka int primary key auto_increment not null,
nom_judoka varchar(50) not null, 
prenom_judoka varchar(50) not null, 
age_judoka tinyint(3) not null,
id_sexe INT NOT NULL,
id_ceinture INT NOT NULL
)engine=innoDB;

CREATE TABLE sexe(
id_sexe int primary key auto_increment not null,
type_sexe char(1) not null
)engine=innoDB;

CREATE TABLE ceinture(
id_ceinture int primary key auto_increment not null,
couleur_ceinture varchar(7) not null
)engine=innoDB;

CREATE TABLE competition(
id_competition int primary key auto_increment not null,
nom_competition varchar(50) not null,
debut_competition date not null,
fin_competition date not null
)engine=innoDB;

-- Création de la (1) table d'association : participer =>
CREATE TABLE participer(
id_competition int not null,
id_judoka int not null,
primary key(id_judoka, id_competition)
)engine=innoDB;

-- Création des (4) contraintes : etre_sexe, posseder_ceinture, participer_judoka, participer_competition => 
ALTER TABLE judoka
ADD CONSTRAINT fk_posseder_ceinture
FOREIGN KEY(id_ceinture)
REFERENCES ceinture(id_ceinture);

ALTER TABLE judoka
add constraint fk_etre_sexe
foreign key(id_sexe)
references sexe(id_sexe);

ALTER TABLE participer
add constraint fk_participer_competition
foreign key(id_competition)
references competition(id_competition);

ALTER TABLE participer
add constraint fk_participer_judoka
foreign key (id_judoka)
references judoka(id_judoka);